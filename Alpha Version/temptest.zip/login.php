<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="cart.css">
<script type="text/javascript" src="template.js"></script>
<title>BallotBox</title>
</head>
<body onload="load()">
<div id="top">
    <img id="logobox" src="logo.png">
    <div id="centertop">
        <div id="adspace1">
        <p>Ad Space 1</p>
        </div>
        <div id="menu">
                <button id="about">About</button>
                <button id="selltix">Sell Tickets</button>
                <button id="faq">FAQ/Help</button>
                <button id="contact">Contact</button>
        </div>
    </div>
    <div id="options">
        <p>Login/Register</p>
        <p>Report Ticket</p>
        <div id="loginreg">
        </div>
        <div id="report">
        </div>
    </div>
</div>
<div id="center">
    <div id="loginbox">
        <img id= "logobox" src="logo.png">
        <form>
        Username<input id="username" type="input">
        Password<input id="password" type="password">
        </form>
    </div>
</div>
</body>
</html>
